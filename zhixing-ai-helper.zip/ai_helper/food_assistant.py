﻿# -*- coding: utf-8 -*-
"""知行饭店小助手 · 只懂饭店系统。知识库优先，小而精。"""
from __future__ import annotations

import json
from pathlib import Path

KB = [
    (["装", "安装", "解压"], "别急，跟我做4步：\n1. 对准压缩包点右键→解压\n2. 打开文件夹，进「Windows版」\n3. 双击 start_app.bat\n4. 跟着提示点下一步\n没反应就先装「VC++运行时」。"),
    (["手机", "apk", "安卓"], "1. 把APK发到手机微信/QQ\n2. 点开安装，允许未知来源\n3. 打开「知行饭店」\n手机和电脑连同一个WiFi。"),
    (["激活", "激活码", "授权"], "点「设置」→「授权管理」→粘贴激活码→激活。机器码也在这页复制，买码前发给卖家。"),
    (["机器码"], "机器码是这台电脑的编号，在「设置→授权管理」复制，发给卖家才能出激活码。"),
    (["试用", "到期"], "7天试用结束后要激活：复制机器码发给卖家，拿到码后在授权管理粘贴激活。"),
    (["开台", "点餐", "点菜"], "1. 主页→收银台\n2. 左侧选分类\n3. 点菜加入订单\n4. 结账→选桌号→选支付方式。"),
    (["结账", "收钱", "买单"], "1. 主页→结账\n2. 选桌台\n3. 选现金/微信/支付宝/会员余额\n4. 现金要填客人给的钱数。"),
    (["后厨", "出餐", "催菜"], "主页→后厨。可催菜、出餐；出餐后前台自动知道。"),
    (["扫码点餐", "桌码", "二维码"], "主页→网络→扫码点餐，生成桌码给客人扫。同一WiFi，电脑别关机。"),
    (["打印", "小票", "不打印"], "先通电有纸→打测试页。USB换口，网络打印机查IP。测试页也不出就是驱动问题。"),
    (["交接班", "交班"], "设置→交接班，看统计后点交班，新班次从0开始。"),
    (["备份"], "设置里找备份/数据管理，点备份存到U盘或D盘。重装前一定先备。"),
    (["密码", "忘记密码"], "默认管理员/admin123。员工密码管理员重置。管理员忘记请联系卖家。"),
    (["连不上", "网络", "手机连"], "同一WiFi→电脑开服务→手机填服务器IP→连上自动同步。"),
    (["会员", "充值"], "会员管理→搜手机号→充值→选支付方式。"),
    (["桌台", "并台", "转台"], "在桌台管理/收银台里改桌台状态。并台转台请专业版及以上。"),
    (["你好", "你是谁", "在吗"], "我是知行饭店小助手，只负责饭店系统：装软件、点餐结账、打印、激活、备份。"),
    (["万能", "破解"], "没有万能码，也不能给。请复制机器码找卖家买正版激活。"),
]

QUICK = [
    "怎么安装到电脑上？", "怎么装到手机？", "激活码在哪里填？",
    "怎么开台点餐？", "怎么结账？", "打印机不打印？",
    "怎么备份数据？", "手机连不上电脑？",
]
GREETING = "您好，我是知行饭店小助手。装软件、点餐结账、打印激活，您问我一步步说。"


def answer(q: str) -> dict:
    # 优先走真智能内核（向导/排障/代填/查询）
    try:
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from smart_core import SmartAssistant
        smart = SmartAssistant("food").handle(q)
        if smart.kind in ("wizard", "diagnose", "query") or (
            smart.kind == "guide" and smart.actions
        ):
            return {
                "text": smart.reply,
                "source": "smart",
                "product": "food",
                "actions": smart.actions,
                "steps": smart.steps,
                "diagnosis": smart.diagnosis,
                "need_input": smart.need_input,
                "kind": smart.kind,
            }
    except Exception:
        pass

    u = q.lower()
    best, score = None, 0
    for keys, ans in KB:
        s = sum(1 for k in keys if k in u or k in q)
        if s > score:
            score, best = s, ans
    text = best if best and score >= 1 else (
        "这个问题我记不太准步骤，怕说错耽误您。您可以换个说法，比如「怎么安装」「怎么结账」「激活码在哪」。也可以看说明书或问卖家。"
    )
    source = "kb" if best and score >= 1 else "fallback"

    # 一键直达动作（手脚）
    actions = []
    pairs = [
        (["激活", "激活码", "注册码", "授权"], {"id": "food.license", "label": "一键去填激活码", "route": "/settings/license", "hint": "机器码同页复制"}),
        (["打印", "小票"], {"id": "food.printer", "label": "一键去打印机设置", "route": "/settings/hardware", "hint": "点「测试打印」"}),
        (["备份"], {"id": "food.backup", "label": "一键去备份数据", "route": "/settings/backup", "hint": "存U盘或D盘"}),
        (["网络", "手机连", "连不上"], {"id": "food.network", "label": "一键去网络设置", "route": "/settings/network", "hint": "同一WiFi"}),
        (["安装", "装", "解压"], {"id": "food.install", "label": "打开安装指引", "route": "/help/install", "hint": ""}),
        (["点餐", "开台", "点菜"], {"id": "food.pos", "label": "一键去收银台", "route": "/pos", "hint": ""}),
        (["结账", "收钱", "买单"], {"id": "food.checkout", "label": "一键去结账", "route": "/checkout", "hint": ""}),
        (["后厨", "出餐", "催菜"], {"id": "food.kitchen", "label": "一键去后厨", "route": "/kitchen", "hint": ""}),
        (["扫码", "桌码"], {"id": "food.qr", "label": "一键开扫码点餐", "route": "/network/qrcode", "hint": ""}),
        (["会员", "充值"], {"id": "food.member", "label": "一键去会员管理", "route": "/member", "hint": ""}),
        (["交接班", "交班"], {"id": "food.shift", "label": "一键去交接班", "route": "/settings/shift", "hint": ""}),
    ]
    seen = set()
    for keys, act in pairs:
        if any(k in u or k in q for k in keys) and act["id"] not in seen:
            seen.add(act["id"])
            actions.append(act)
        if len(actions) >= 3:
            break

    # 客户直接贴了激活码 → 帮忙填
    import re
    m = re.search(r"ZX-[A-Za-z0-9]+(?:-[A-Za-z0-9]+){1,4}", q)
    if m:
        actions.insert(0, {
            "id": "food.license_paste",
            "label": "帮我填入激活码",
            "route": "/settings/license",
            "hint": "已填好，您点「激活」即可",
            "autoFill": {"activationCode": m.group(0)},
        })

    return {"text": text, "source": source, "product": "food", "actions": actions}


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--q", default="怎么结账？")
    a = ap.parse_args()
    print(json.dumps(answer(a.q), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

