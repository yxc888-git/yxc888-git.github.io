"""
知行小助手 · 动作目录（与 Flutter zhixing_actions.dart 同口径）
给 Web/本地版一键直达：返回 route + label，宿主用深链跳进主软件。
"""
from __future__ import annotations

from typing import Any

FOOD_ACTIONS: list[dict[str, Any]] = [
    {"id": "food.install_guide", "label": "打开安装指引", "route": "/help/install", "hint": "按步骤装软件", "keys": ["安装", "装", "解压"]},
    {"id": "food.pos", "label": "一键去收银台", "route": "/pos", "hint": "开台点餐", "keys": ["开台", "点餐", "点菜"]},
    {"id": "food.checkout", "label": "一键去结账", "route": "/checkout", "hint": "选桌收钱", "keys": ["结账", "收钱", "买单"]},
    {"id": "food.kitchen", "label": "一键去后厨", "route": "/kitchen", "hint": "催菜/出餐", "keys": ["后厨", "出餐", "催菜"]},
    {"id": "food.menu", "label": "一键去菜品管理", "route": "/menu", "hint": "加菜改价", "keys": ["菜品", "加菜"]},
    {"id": "food.tables", "label": "一键去桌台管理", "route": "/tables", "hint": "改桌号", "keys": ["桌台", "桌子"]},
    {"id": "food.printer", "label": "一键去打印机设置", "route": "/settings/hardware", "hint": "点「测试打印」", "keys": ["打印", "小票"]},
    {"id": "food.license", "label": "一键去填激活码", "route": "/settings/license", "hint": "机器码同页复制", "keys": ["激活", "激活码", "注册码"]},
    {"id": "food.backup", "label": "一键去备份数据", "route": "/settings/backup", "hint": "收工前备一份", "keys": ["备份"]},
    {"id": "food.network", "label": "一键去网络设置", "route": "/settings/network", "hint": "手机连电脑", "keys": ["网络", "手机连", "连不上"]},
    {"id": "food.qr_order", "label": "一键开扫码点餐", "route": "/network/qrcode", "hint": "生成桌码", "keys": ["扫码", "桌码"]},
    {"id": "food.member", "label": "一键去会员管理", "route": "/member", "hint": "充值积分", "keys": ["会员", "充值"]},
    {"id": "food.shift", "label": "一键去交接班", "route": "/settings/shift", "hint": "看统计点交班", "keys": ["交接班", "交班"]},
    {"id": "food.inventory", "label": "一键去库存", "route": "/inventory", "hint": "进销存预警", "keys": ["库存"]},
]

BEAUTY_ACTIONS: list[dict[str, Any]] = [
    {"id": "beauty.install_guide", "label": "打开安装指引", "route": "/help/install", "hint": "按步骤装软件", "keys": ["安装", "装"]},
    {"id": "beauty.pos", "label": "一键去收银开单", "route": "/pos", "hint": "做服务收钱", "keys": ["开单", "收银", "收钱"]},
    {"id": "beauty.appointment", "label": "一键去预约管理", "route": "/appointment", "hint": "新增确认预约", "keys": ["预约"]},
    {"id": "beauty.member", "label": "一键去会员管理", "route": "/member", "hint": "充值等级", "keys": ["会员", "充值"]},
    {"id": "beauty.staff", "label": "一键去员工/提成", "route": "/staff", "hint": "设提成看业绩", "keys": ["提成", "员工", "技师"]},
    {"id": "beauty.service", "label": "一键去服务项目", "route": "/service", "hint": "改项目价格", "keys": ["服务项目"]},
    {"id": "beauty.inventory", "label": "一键去库存", "route": "/inventory", "hint": "产品进销存", "keys": ["库存"]},
    {"id": "beauty.wifi_qr", "label": "一键去WiFi工位码", "route": "/wifi-qr", "hint": "生成打印", "keys": ["工位码"]},
    {"id": "beauty.printer", "label": "一键去打印机设置", "route": "/settings/printer", "hint": "测试打印", "keys": ["打印"]},
    {"id": "beauty.license", "label": "一键去填激活码", "route": "/settings/license", "hint": "机器码同页复制", "keys": ["激活", "激活码", "注册码"]},
    {"id": "beauty.backup", "label": "一键去备份数据", "route": "/settings/backup", "hint": "设置→系统信息", "keys": ["备份"]},
    {"id": "beauty.network", "label": "一键去网络配置", "route": "/settings/network", "hint": "端口8090", "keys": ["网络", "连不上", "8090"]},
    {"id": "beauty.marketing", "label": "一键去营销工具", "route": "/marketing", "hint": "充值赠送等活动", "keys": ["营销", "活动"]},
]


def suggest_actions(user: str, product: str) -> list[dict[str, Any]]:
    pool = BEAUTY_ACTIONS if product == "beauty" else FOOD_ACTIONS
    hit = []
    for a in pool:
        if any(k in user for k in a.get("keys", [])):
            hit.append({k: a[k] for k in ("id", "label", "route", "hint")})
    return hit


def paste_license_action(code: str, product: str) -> dict[str, Any]:
    return {
        "id": f"{product}.license_paste",
        "label": "帮我填入激活码",
        "route": "/settings/license",
        "hint": "已填好，您点「激活」即可",
        "autoFill": {"activationCode": code.strip()},
    }
