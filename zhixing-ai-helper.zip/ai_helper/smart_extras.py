# -*- coding: utf-8 -*-
"""
知行小 AI · 补齐件
================
1) 只读业务接口契约（主软件实现后，AI 能查能念）
2) 启动主动提醒
3) 小模型 JSON 意图（可选，0.5B 输出结构化意图）
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, asdict
from typing import Any, Callable, Optional


# ============================================================
# 1. 只读业务接口 —— 主软件实现 HostBusinessApi 即可
# ============================================================
@dataclass
class SalesSnapshot:
    date: str
    cash: float = 0.0
    wechat: float = 0.0
    alipay: float = 0.0
    member: float = 0.0
    total: float = 0.0
    order_count: int = 0
    unpaid_tables: int = 0  # 饭店：待结账桌
    today_appointments: int = 0  # 美业：今日预约

    def speak_cn(self, product: str) -> str:
        pay = f"现金 {self.cash:.0f}，微信 {self.wechat:.0f}，支付宝 {self.alipay:.0f}，会员卡 {self.member:.0f}"
        if product == "food":
            return (
                f"今天一共收了约 {self.total:.0f} 元，{self.order_count} 单。"
                f"分项：{pay}。还有 {self.unpaid_tables} 桌未结账。"
            )
        return (
            f"今天一共收了约 {self.total:.0f} 元，{self.order_count} 单。"
            f"分项：{pay}。今日预约 {self.today_appointments} 个。"
        )


class HostBusinessApi:
    """主软件只读接口。默认返回 None=未接入。"""

    def today_sales(self) -> Optional[SalesSnapshot]:
        return None

    def low_stock(self) -> list[dict]:
        return []

    def trial_days_left(self) -> Optional[int]:
        return None

    def backup_last_time(self) -> Optional[str]:
        return None

    def printer_online(self) -> Optional[bool]:
        return None


# ============================================================
# 2. 启动主动提醒
# ============================================================
@dataclass
class ProactiveTip:
    level: str  # info | warn
    text: str
    action_id: str = ""
    action_label: str = ""


def build_proactive_tips(api: HostBusinessApi, product: str) -> list[ProactiveTip]:
    tips: list[ProactiveTip] = []
    days = api.trial_days_left()
    if days is not None:
        if days <= 0:
            tips.append(ProactiveTip(
                "warn",
                "试用已到期，请尽快激活，否则部分功能会停。",
                "license", "一键去填激活码",
            ))
        elif days <= 3:
            tips.append(ProactiveTip(
                "warn",
                f"试用还剩 {days} 天，建议提前激活。",
                "license", "一键去填激活码",
            ))
    if api.printer_online() is False:
        tips.append(ProactiveTip(
            "warn",
            "检测到打印机可能离线，点我可以自检。",
            "printer", "自检打印机",
        ))
    if api.backup_last_time() is None:
        tips.append(ProactiveTip(
            "info",
            "还没做过数据备份，收工前备一份更安心。",
            "backup", "一键去备份",
        ))
    if product == "food" and api.today_sales() and api.today_sales().unpaid_tables > 0:
        tips.append(ProactiveTip(
            "info",
            f"还有 {api.today_sales().unpaid_tables} 桌未结账。",
            "checkout", "一键去结账",
        ))
    return tips


# ============================================================
# 3. 小模型 JSON 意图（输出约束，可由 0.5B 生成）
# ============================================================
INTENT_SCHEMA_DOC = """只输出 JSON，不要其它字：
{"intent":"wizard|diagnose|query|guide|paste_license|fallback","name":"pay_wechat|printer_usb|...","slots":{"code":"ZX-..."}}
"""

INTENT_MAP = {
    "pay_wechat": "wizard",
    "pay_alipay": "wizard",
    "printer_usb": "wizard",
    "printer_net": "wizard",
    "qr_order": "wizard",
    "import_menu": "wizard",
    "api_waimai": "wizard",
    "init_shop": "wizard",
    "diagnose_printer": "diagnose",
    "diagnose_network": "diagnose",
    "diagnose_payment": "diagnose",
    "today_sales": "query",
}


def parse_llm_intent(raw: str) -> dict:
    """解析小模型输出的 JSON 意图；失败则 {}。"""
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        return {}
    blob = m.group(0)
    obj = None
    try:
        obj = json.loads(blob)
    except Exception:
        mi = re.search(r'"intent"\s*:\s*"([^"]+)"', blob)
        mn = re.search(r'"name"\s*:\s*"([^"]+)"', blob)
        mc = re.search(r'"code"\s*:\s*"([^"]+)"', blob)
        if not mi:
            return {}
        obj = {"intent": mi.group(1), "name": mn.group(1) if mn else "", "slots": {}}
        if mc:
            obj["slots"] = {"code": mc.group(1)}
    if not isinstance(obj, dict):
        return {}
    intent = obj.get("intent")
    name = obj.get("name") or ""
    if intent == "wizard" and name in INTENT_MAP:
        return {"intent": "wizard", "name": name, "slots": obj.get("slots") or {}}
    if intent in ("diagnose", "query", "guide", "paste_license", "fallback"):
        return {"intent": intent, "name": name, "slots": obj.get("slots") or {}}
    return {}


def say_sales(snap: SalesSnapshot, product: str) -> str:
    return snap.speak_cn(product)
