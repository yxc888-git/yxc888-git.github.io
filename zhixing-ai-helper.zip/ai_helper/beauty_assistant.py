﻿# -*- coding: utf-8 -*-
"""知行美业小助手 · 只懂美业系统。知识库优先，小而精。"""
from __future__ import annotations

import json

KB = [
    (["装", "安装"], "1. 双击 zhixing_beauty\n2. 账号 admin 密码 admin123\n3. 首次登录改成自己的密码\n黑屏就接显示器或用远程桌面。"),
    (["手机", "apk"], "设置→手机端下载扫码，或微信传APK安装。填电脑IP，同一WiFi。"),
    (["开单", "收银", "收钱"], "业务→收银开单→点服务→可选技师会员→结算选现金/微信/支付宝/会员卡。"),
    (["预约"], "预约管理→新增→姓名手机→选服务时间技师→确认。客户也可扫码预约。"),
    (["看不到", "预约不显示"], "等30秒自动刷新，或切换日期再切回。"),
    (["会员", "充值"], "业务→会员管理→搜人→充值→选支付方式。"),
    (["等级", "折扣", "银卡", "金卡", "钻石"], "常见：普通无折扣，银卡满2000约9.5折，金卡满5000约9折，钻石满10000约8.5折。以软件设置为准。"),
    (["提成"], "员工管理设提成比例。开单时选技师，报表看明细。"),
    (["工位码", "wifi"], "更多→WiFi工位码→填WiFi密码工位号→生成打印。WiFi改了要重生成。"),
    (["备份"], "设置→系统信息→备份数据。"),
    (["激活", "授权"], "设置里的授权管理，粘贴激活码。机器码同页复制发卖家。"),
    (["连不上", "8090", "网络"], "电脑软件已开、同一WiFi、IP正确、防火墙放行8090。"),
    (["黑屏", "打不开"], "多半没接显示器。接屏幕再开，或用Windows远程桌面。"),
    (["密码"], "默认admin/admin123，首次登录强制改密码。忘记找卖家重置。"),
    (["库存", "产品"], "产品库存里管进销存。服务消耗可自动扣库存。"),
    (["营销", "生日", "充值赠送"], "营销工具支持充值赠送、生日营销、新客优惠等。"),
    (["你好", "你是谁"], "我是知行美业小助手，只负责美业系统：装软件、开单、预约、会员、提成。"),
    (["万能", "破解"], "没有万能码。请复制机器码找卖家正规激活。"),
]

QUICK = [
    "电脑上怎么安装？", "怎么开单收钱？", "怎么给会员充值？",
    "客户怎么扫码预约？", "技师提成怎么设置？", "手机连不上电脑？",
    "数据怎么备份？", "激活码在哪填？",
]
GREETING = "您好，我是知行美业小助手。装软件、开单、预约、会员、提成，您问我一步步说。"


def answer(q: str) -> dict:
    try:
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from smart_core import SmartAssistant
        smart = SmartAssistant("beauty").handle(q)
        if smart.kind in ("wizard", "diagnose", "query") or (
            smart.kind == "guide" and smart.actions
        ):
            return {
                "text": smart.reply,
                "source": "smart",
                "product": "beauty",
                "actions": smart.actions,
                "steps": smart.steps,
                "diagnosis": smart.diagnosis,
                "need_input": smart.need_input,
                "kind": smart.kind,
            }
    except Exception:
        pass

    u = q.lower()
    best, score = None, 0
    for keys, ans in KB:
        s = sum(1 for k in keys if k in u or k in q)
        if s > score:
            score, best = s, ans
    text = best if best and score >= 1 else (
        "这个问题我记不太准步骤，怕说错耽误您。您可以换个说法，比如「怎么安装」「怎么开单」「激活码在哪」。也可以看说明书或问卖家。"
    )
    source = "kb" if best and score >= 1 else "fallback"

    actions = []
    pairs = [
        (["激活", "激活码", "注册码", "授权"], {"id": "beauty.license", "label": "一键去填激活码", "route": "/settings/license", "hint": "机器码同页复制"}),
        (["打印"], {"id": "beauty.printer", "label": "一键去打印机设置", "route": "/settings/printer", "hint": "点测试打印"}),
        (["备份"], {"id": "beauty.backup", "label": "一键去备份数据", "route": "/settings/backup", "hint": ""}),
        (["网络", "连不上", "8090", "手机连"], {"id": "beauty.network", "label": "一键去网络配置", "route": "/settings/network", "hint": "端口8090"}),
        (["安装", "装"], {"id": "beauty.install", "label": "打开安装指引", "route": "/help/install", "hint": ""}),
        (["开单", "收银", "收钱"], {"id": "beauty.pos", "label": "一键去收银开单", "route": "/pos", "hint": ""}),
        (["预约"], {"id": "beauty.appointment", "label": "一键去预约管理", "route": "/appointment", "hint": ""}),
        (["会员", "充值"], {"id": "beauty.member", "label": "一键去会员管理", "route": "/member", "hint": ""}),
        (["提成", "员工", "技师"], {"id": "beauty.staff", "label": "一键去员工/提成", "route": "/staff", "hint": ""}),
        (["工位码"], {"id": "beauty.wifi_qr", "label": "一键去WiFi工位码", "route": "/wifi-qr", "hint": ""}),
        (["营销", "活动"], {"id": "beauty.marketing", "label": "一键去营销工具", "route": "/marketing", "hint": ""}),
    ]
    seen = set()
    for keys, act in pairs:
        if any(k in u or k in q for k in keys) and act["id"] not in seen:
            seen.add(act["id"])
            actions.append(act)
        if len(actions) >= 3:
            break

    import re
    m = re.search(r"ZX-[A-Za-z0-9]+(?:-[A-Za-z0-9]+){1,4}", q)
    if m:
        actions.insert(0, {
            "id": "beauty.license_paste",
            "label": "帮我填入激活码",
            "route": "/settings/license",
            "hint": "已填好，您点「激活」即可",
            "autoFill": {"activationCode": m.group(0)},
        })

    return {"text": text, "source": source, "product": "beauty", "actions": actions}


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--q", default="怎么开单收钱？")
    a = ap.parse_args()
    print(json.dumps(answer(a.q), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

