@echo off
chcp 65001 >nul
title 知行小AI助手
echo ========================================
echo   知行小AI助手（离线）
echo   可教您安装/使用：饭店系统、美业系统
echo ========================================
echo.
echo 请选择要帮的软件：
echo   1 = 饭店系统
echo   2 = 美业系统
echo.
set /p CHOICE=请输入 1 或 2 后回车:
if "%CHOICE%"=="2" (
  start "" http://127.0.0.1:8765/?product=beauty
  python "%~dp0local_server.py"
) else (
  start "" http://127.0.0.1:8765/?product=food
  python "%~dp0local_server.py"
)
if errorlevel 1 (
  echo.
  echo 若提示缺少 Python，请安装 Python 3 后重试，或联系卖家。
  pause
)
