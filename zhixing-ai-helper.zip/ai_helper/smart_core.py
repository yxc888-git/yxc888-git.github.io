# -*- coding: utf-8 -*-
"""
知行小 AI · 真智能内核
====================
小模型负责「听懂」；本模块负责「办事」。
所有能力离线、可审计、白名单执行。

用法（Python 本地/服务）:
    from smart_core import SmartAssistant
    a = SmartAssistant(product="food")
    r = a.handle("帮我接微信支付")
    print(r)  # steps + actions + diagnosis
"""

from __future__ import annotations

import json
import re
import socket
import subprocess
from dataclasses import dataclass, field, asdict
from typing import Any, Callable
from pathlib import Path as _Path

_RULES_PATH = _Path(__file__).resolve().parent / "ai_rules.json"
try:
    AI_RULES = json.loads(_RULES_PATH.read_text(encoding="utf-8")) if _RULES_PATH.exists() else {}
except Exception:
    AI_RULES = {}


def _rule_keys(section: str, default: list[str] | None = None) -> list[str]:
    obj = AI_RULES.get(section) or {}
    return list(obj.get("keys") or default or [])


# ---------------- 结果结构 ----------------
@dataclass
class SmartResult:
    reply: str
    kind: str  # guide | diagnose | wizard | query | refuse | fallback
    steps: list[str] = field(default_factory=list)
    actions: list[dict] = field(default_factory=list)
    diagnosis: dict = field(default_factory=dict)
    need_input: list[str] = field(default_factory=list)  # 向导还缺什么信息
    data: dict = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False, indent=2)


# ---------------- 动作目录（手脚）----------------
# route 与主软件对齐；host 可 override
ACTIONS = {
    "food": {
        "pay_wechat": {"id": "food.pay_wechat", "label": "打开微信支付配置", "route": "/settings/payment", "hint": "填商户号/密钥"},
        "pay_alipay": {"id": "food.pay_alipay", "label": "打开支付宝配置", "route": "/settings/payment", "hint": "填AppID/密钥"},
        "pay_test": {"id": "food.pay_test", "label": "发起1分钱测试收款", "route": "/settings/payment/test", "hint": "验证是否到账"},
        "printer": {"id": "food.printer", "label": "一键去打印机设置", "route": "/settings/hardware", "hint": "选型号后测试打印"},
        "printer_test": {"id": "food.printer_test", "label": "打印测试页", "route": "/settings/hardware", "hint": "auto=test_print"},
        "qr_order": {"id": "food.qr_order", "label": "一键开扫码点餐", "route": "/network/qrcode", "hint": "生成桌码"},
        "import_dish": {"id": "food.import_dish", "label": "打开菜品导入", "route": "/menu/import", "hint": "用Excel模板"},
        "import_member": {"id": "food.import_member", "label": "打开会员导入", "route": "/member/import", "hint": ""},
        "api_open": {"id": "food.api_open", "label": "打开接口/外卖对接", "route": "/settings/api", "hint": "旗舰版"},
        "backup": {"id": "food.backup", "label": "一键去备份", "route": "/settings/backup", "hint": ""},
        "license": {"id": "food.license", "label": "一键去填激活码", "route": "/settings/license", "hint": ""},
        "network": {"id": "food.network", "label": "一键去网络设置", "route": "/settings/network", "hint": ""},
        "pos": {"id": "food.pos", "label": "一键去收银台", "route": "/pos", "hint": ""},
        "checkout": {"id": "food.checkout", "label": "一键去结账", "route": "/checkout", "hint": ""},
    },
    "beauty": {
        "pay_wechat": {"id": "beauty.pay_wechat", "label": "打开微信支付配置", "route": "/settings/payment", "hint": ""},
        "pay_alipay": {"id": "beauty.pay_alipay", "label": "打开支付宝配置", "route": "/settings/payment", "hint": ""},
        "pay_test": {"id": "beauty.pay_test", "label": "发起1分钱测试收款", "route": "/settings/payment/test", "hint": ""},
        "printer": {"id": "beauty.printer", "label": "一键去打印机设置", "route": "/settings/printer", "hint": ""},
        "printer_test": {"id": "beauty.printer_test", "label": "打印测试页", "route": "/settings/printer", "hint": "auto=test_print"},
        "wifi_qr": {"id": "beauty.wifi_qr", "label": "一键去WiFi工位码", "route": "/wifi-qr", "hint": ""},
        "import_member": {"id": "beauty.import_member", "label": "打开会员导入", "route": "/member/import", "hint": ""},
        "import_product": {"id": "beauty.import_product", "label": "打开产品导入", "route": "/inventory/import", "hint": ""},
        "api_open": {"id": "beauty.api_open", "label": "打开接口设置", "route": "/settings/api", "hint": ""},
        "backup": {"id": "beauty.backup", "label": "一键去备份", "route": "/settings/backup", "hint": ""},
        "license": {"id": "beauty.license", "label": "一键去填激活码", "route": "/settings/license", "hint": ""},
        "network": {"id": "beauty.network", "label": "一键去网络配置", "route": "/settings/network", "hint": ""},
        "pos": {"id": "beauty.pos", "label": "一键去收银开单", "route": "/pos", "hint": ""},
        "appointment": {"id": "beauty.appointment", "label": "一键去预约", "route": "/appointment", "hint": ""},
    },
}


def _act(product: str, key: str) -> dict:
    return dict(ACTIONS[product][key])


# ---------------- 对接向导 ----------------
WIZARDS: dict[str, dict[str, Any]] = {
    "pay_wechat": {
        "title": "微信收款对接",
        "intro": "咱们一步步把微信收款接好。您只要有微信支付商户号和密钥（没有就先去微信支付官网开通商户）。",
        "steps": [
            "确认您已有「微信支付商户号」（10位数字）和 API 密钥",
            "我帮您打开「支付配置」页",
            "在「微信支付」栏粘贴商户号、密钥、证书（卖家发的或商户后台下载）",
            "保存后，我帮您发起「1分钱测试收款」",
            "测试成功即可正式收款；失败请把提示告诉我",
        ],
        "need_input": ["商户号", "API密钥"],
        "actions": ["pay_wechat", "pay_test"],
    },
    "pay_alipay": {
        "title": "支付宝收款对接",
        "intro": "一步步接好支付宝。需要支付宝开放平台的 AppID 和应用私钥/公钥。",
        "steps": [
            "准备 AppID、应用私钥、支付宝公钥",
            "打开「支付配置」页",
            "粘贴三项，保存",
            "用1分钱测试收款验证",
        ],
        "need_input": ["AppID", "应用私钥", "支付宝公钥"],
        "actions": ["pay_alipay", "pay_test"],
    },
    "printer_usb": {
        "title": "USB小票打印机",
        "intro": "装USB热敏打印机，大约2分钟。",
        "steps": [
            "打印机接电源并装好纸，USB线插电脑",
            "打开「打印机设置」",
            "类型选「USB热敏」，纸宽选58mm或80mm（看机器）",
            "点「测试打印」——能出字就成了",
            "若不出：换USB口、关掉其他打印机驱动、再测",
        ],
        "need_input": ["纸宽58还是80"],
        "actions": ["printer", "printer_test"],
    },
    "printer_net": {
        "title": "网络打印机",
        "intro": "网口打印机要和收银电脑同一WiFi/局域网。",
        "steps": [
            "打印机插电并连上路由器网线/同一WiFi",
            "看打印机自检页上的IP（或说明书查IP）",
            "打开「打印机设置」→ 类型选「网络打印机」→ 填IP",
            "点「测试打印」",
            "失败就检查：电脑和打印机是否同网段、IP有没有变",
        ],
        "need_input": ["打印机IP"],
        "actions": ["printer", "printer_test", "network"],
    },
    "qr_order": {
        "title": "扫码点餐一条龙",
        "intro": "顾客扫桌码点菜，后厨自动来单。",
        "steps": [
            "打开「扫码点餐」页",
            "生成各桌二维码",
            "点「打印桌码」贴桌上",
            "手机连同一WiFi，扫桌码试一单",
            "确认后厨看板出现订单",
        ],
        "need_input": [],
        "actions": ["qr_order", "network"],
    },
    "import_menu": {
        "title": "菜品/服务导入",
        "intro": "用Excel模板批量导入，不用手敲。",
        "steps": [
            "打开导入页，下载「Excel模板」",
            "按列填：名称、分类、价格（可加规格/图片路径）",
            "保存CSV/Excel后点「选择文件导入」",
            "导入结果里看成功/失败行，失败行可改再导",
        ],
        "need_input": [],
        "actions": ["import_dish"],
    },
    "api_waimai": {
        "title": "外卖/开放接口",
        "intro": "旗舰/连锁功能：对接外卖或第三方系统。",
        "steps": [
            "打开「接口设置」页",
            "记下「接口地址」和「Token」发给对方技术",
            "对方回调地址填到本软件的「回调URL」",
            "用「测试接口」按钮打一枪",
            "成功后订单会自动进系统",
        ],
        "need_input": ["回调URL（对方给）"],
        "actions": ["api_open"],
    },
    "init_shop": {
        "title": "开店初始化",
        "intro": "新店一次配好，大约10分钟。",
        "steps": [
            "改门店名称、电话（设置→门店信息）",
            "导入或手写菜单/服务项目",
            "设打印机并测试",
            "（可选）接微信/支付宝",
            "生成桌码或工位码",
            "做一次备份到U盘/D盘",
        ],
        "need_input": ["店名"],
        "actions": ["printer", "backup"],
    },
}


# ---------------- 排障自检 ----------------
def diagnose_printer() -> dict:
    """轻量自检：不依赖厂商SDK，给可操作结论。"""
    checks = []
    # USB 打印机常见：spooler 服务
    try:
        out = subprocess.check_output(
            ["sc", "query", "Spooler"],
            shell=True,
            stderr=subprocess.DEVNULL,
            timeout=3,
        )
        running = b"RUNNING" in out
        checks.append({"name": "打印后台服务 Spooler", "ok": running,
                       "hint": "服务未启动" if not running else "正常"})
    except Exception as e:
        checks.append({"name": "打印后台服务 Spooler", "ok": None, "hint": f"无法检测: {e}"})

    # 常见打印端口
    for port in (9100, 515, 631):
        s = socket.socket()
        s.settimeout(0.4)
        try:
            s.connect(("127.0.0.1", port))
            checks.append({"name": f"本机打印端口 {port}", "ok": True, "hint": "有服务在听"})
        except Exception:
            checks.append({"name": f"本机打印端口 {port}", "ok": False, "hint": "未监听（网络打印机请查打印机IP:9100）"})
        finally:
            s.close()

    bad = [c for c in checks if c["ok"] is False]
    summary = "打印机相关：优先查电源/纸张/USB线；下面是我能查到的系统状态。"
    if any(c["name"].endswith("Spooler") and c["ok"] is False for c in checks):
        summary = "打印后台服务没启动，所以打不出小票。请在服务里启动「Print Spooler」，或重启电脑后再测。"
    return {"summary": summary, "checks": checks}


def diagnose_network(port: int = 8090) -> dict:
    checks = []
    # 本机端口
    s = socket.socket()
    s.settimeout(0.4)
    try:
        s.connect(("127.0.0.1", port))
        checks.append({"name": f"本机端口 {port}", "ok": True, "hint": "软件服务在跑"})
    except Exception:
        checks.append({"name": f"本机端口 {port}", "ok": False,
                       "hint": "端口没开：先打开主软件服务；若被占用请改端口"})
    finally:
        s.close()
    # 外网（支付回调需要）
    for host in ("www.baidu.com", "api.mch.weixin.qq.com"):
        s = socket.socket()
        s.settimeout(1.0)
        try:
            s.connect((host, 443))
            checks.append({"name": f"外网 {host}", "ok": True, "hint": "可访问"})
        except Exception:
            checks.append({"name": f"外网 {host}", "ok": False, "hint": "连不上：查路由器/网线；收现金没事，在线支付会失败"})
        finally:
            s.close()
    bad = [c for c in checks if c["ok"] is False]
    summary = "网络基本正常。" if not bad else "网络有问题：" + "；".join(c["hint"] for c in bad)
    return {"summary": summary, "checks": checks}


def diagnose_license(text: str = "") -> dict:
    checks = [
        {"name": "激活码格式", "ok": bool(re.search(r"ZX-[A-Za-z0-9]+(-[A-Za-z0-9]+){1,4}", text)),
         "hint": "应类似 ZX-XXXX-XXXX-XXXX"},
        {"name": "提示", "ok": None, "hint": "换电脑要重新用新机器码出码；复制时别带空格"},
    ]
    return {"summary": "激活码请整段复制，不要少字符。", "checks": checks}


DIAGNOSES = {
    "printer": ("打印机/小票", diagnose_printer),
    "network": ("网络/手机连接", lambda: diagnose_network()),
    "payment": ("支付/收款", lambda: diagnose_network()),  # 支付依赖外网
    "license": ("激活/授权", diagnose_license),
}


# ---------------- 主助手 ----------------
class SmartAssistant:
    def __init__(self, product: str = "food"):
        assert product in ("food", "beauty")
        self.product = product

    # ---- 意图识别（可被小模型替换为 JSON 输出）----
    def parse_intent(self, text: str) -> tuple[str, dict]:
        t = text.lower()
        # P1-2 / P2-6：破解拒答、危险指令拒答优先
        pirate_keys = _rule_keys('refuse', ['万能激活码', '万能码', '破解', '盗版', '免费激活码', '怎么破解'])
        if any(k in text for k in pirate_keys):
            return 'refuse', {'topic': 'pirate'}
        danger_keys = _rule_keys('danger_refuse', ['删掉所有', '删数据', '删除桌台', '清空数据', '改成1元', '价格改成1元', '把价格改成', '把营业额改', '伪造', '篡改'])
        if any(k in text for k in danger_keys):
            return 'refuse', {'topic': 'danger'}
        # P1-1：支付失败/没到账 优先于 接微信向导
        pay_fail = list((AI_RULES.get('intents') or {}).get('payment_fail', {}).get('any') or [])
        pay_fail += list((AI_RULES.get('intents') or {}).get('not_received', {}).get('any') or [])
        if not pay_fail:
            pay_fail = ['支付失败', '收款失败', '付不了', '不能支付', '支付不成功', '微信支付失败', '没收到钱', '没到账', '付了钱没收到', '收不到钱', '钱没到']
        if any(k in text for k in pay_fail):
            return 'diagnose', {'which': 'payment'}
        if re.search(r"zx-[a-z0-9]+(-[a-z0-9]+){2,4}", text, re.I):
            code = re.search(r"zx-[a-z0-9]+(-[a-z0-9]+){1,4}", text, re.I).group(0)
            return "paste_license", {"code": code}

        if any(k in t for k in ["微信", "wechat", "wxpay"]):
            if any(k in t for k in ["接", "配置", "对接", "开通", "设置", "怎么弄"]):
                return "wizard", {"name": "pay_wechat"}
            return "guide", {"topic": "pay_wechat"}
        if any(k in t for k in ["支付宝", "alipay"]):
            if any(k in t for k in ["接", "配置", "对接", "开通", "设置", "怎么弄"]):
                return "wizard", {"name": "pay_alipay"}
            return "guide", {"topic": "pay_alipay"}
        if any(k in t for k in ["打印", "小票", "出纸"]):
            if any(k in t for k in ["修", "不打", "不行", "失败", "排错", "没反应", "出问题", "坏了", "出不了", "没法打", "没字"]):
                return "diagnose", {"which": "printer"}
            if any(k in t for k in ["网口", "网络打印", "网线"]):
                return "wizard", {"name": "printer_net"}
            return "wizard", {"name": "printer_usb"}
        if any(k in t for k in ["扫码点餐", "桌码", "扫码点"]):
            return "wizard", {"name": "qr_order"}
        if any(k in t for k in ["导入", "批量", "excel", "csv"]) and any(k in t for k in ["菜", "服务", "项目", "产品", "会员"]):
            return "wizard", {"name": "import_menu"}
        if any(k in t for k in ["外卖", "接口", "api", "对接第三方"]):
            return "wizard", {"name": "api_waimai"}
        if any(k in t for k in ["初始化", "新店", "开店", "刚装好"]):
            return "wizard", {"name": "init_shop"}
        if any(k in t for k in ["连不上", "手机连", "网络", "wifi"]):
            return "diagnose", {"which": "network"}
        if any(k in t for k in ["支付失败", "收不到钱", "收款失败"]):
            return "diagnose", {"which": "payment"}
        if any(k in t for k in ["激活", "激活码", "注册码"]):
            return "guide", {"topic": "license"}
        if any(k in t for k in ["今天营业额", "今日营业额", "今天营收", "营业额", "营收", "卖了多少", "今天收", "今日收"]):
            return "query", {"name": "today_sales"}
        return "fallback", {}

    def handle(self, text: str) -> SmartResult:
        intent, slots = self.parse_intent(text)
        if intent == "refuse":
            topic = slots.get("topic", "danger")
            if topic == "pirate":
                msg = ("没有万能码，我也不能给、不能生成。激活码必须按机器码找卖家买正版。"
                       if self.product == "food"
                       else "没有万能码，我也不能给、不能生成。请复制机器码找卖家买正版激活。")
                return SmartResult(reply=msg, kind="refuse",
                                   actions=[_act(self.product, "license")])
            return SmartResult(
                reply="这类改数据/删数据/改价的操作，我不能代劳，也不能替您点。请店长/管理员在软件里按权限操作。",
                kind="refuse", actions=[])
        if intent == "wizard":
            return self._wizard(slots["name"])
        if intent == "diagnose":
            return self._diagnose(slots["which"], text)
        if intent == "paste_license":
            return self._paste_license(slots["code"])
        if intent == "guide":
            return self._guide(slots.get("topic", ""))
        if intent == "query":
            return self._query(slots.get("name", ""))
        # 与 exe 同口径：再走产品知识库
        from product_kb import answer as kb_answer
        text, src = kb_answer(text, self.product)
        if src == "kb":
            return SmartResult(reply=text, kind="kb",
                               actions=[_act(self.product, k) for k in list(ACTIONS[self.product])[:3]])
        return SmartResult(
            reply="我可以帮您：接微信/支付宝、装打印机、开扫码点餐、导入菜品会员、排查支付/打印/网络、查今日营业额。您说想办哪件事？",
            kind="fallback",
            actions=[_act(self.product, k) for k in list(ACTIONS[self.product])[:4]],
        )

    def _wizard(self, name: str) -> SmartResult:
        w = WIZARDS.get(name)
        if not w:
            return SmartResult(reply="这个向导还没装上，您可以直接问我步骤。", kind="fallback")
        acts = [_act(self.product, a) for a in w["actions"] if a in ACTIONS[self.product]]
        return SmartResult(
            reply=f"【{w['title']}】\n{w['intro']}\n" + "\n".join(f"{i+1}. {s}" for i, s in enumerate(w["steps"])),
            kind="wizard",
            steps=w["steps"],
            actions=acts,
            need_input=w.get("need_input", []),
            data={"wizard": name},
        )

    def _diagnose(self, which: str, text: str = "") -> SmartResult:
        name, fn = DIAGNOSES[which]
        data = fn(text) if which == "license" else fn()
        acts = []
        if which == "printer":
            acts = [_act(self.product, "printer"), _act(self.product, "printer_test")]
        elif which in ("network", "payment"):
            acts = [_act(self.product, "network")]
        elif which == "license":
            acts = [_act(self.product, "license")]
        return SmartResult(
            reply=f"【自检·{name}】\n{data['summary']}\n" +
                  "\n".join(f"· {c['name']}: {c['hint']}" for c in data["checks"]),
            kind="diagnose",
            diagnosis=data,
            actions=acts,
        )

    def _paste_license(self, code: str) -> SmartResult:
        a = _act(self.product, "license")
        a["label"] = "帮我填入激活码"
        a["autoFill"] = {"activationCode": code}
        a["hint"] = "已填好，您点「激活」"
        return SmartResult(
            reply=f"我已识别激活码 {code}，点下面按钮自动填进激活页，您只需点「激活」。",
            kind="wizard",
            actions=[a],
        )

    def _guide(self, topic: str) -> SmartResult:
        mapping = {
            "pay_wechat": ("pay_wechat", "微信收款要商户号和密钥，我可以带您一步步配。"),
            "pay_alipay": ("pay_alipay", "支付宝要 AppID 和密钥，我可以带您一步步配。"),
            "license": ("license", "激活码在「设置→授权管理」，机器码同页复制。"),
        }
        wkey, reply = mapping.get(topic, ("init_shop", "您想办什么？我可以带您做。"))
        return self._wizard(wkey) if topic.startswith("pay") else SmartResult(
            reply=reply, kind="guide", actions=[_act(self.product, topic if topic in ACTIONS[self.product] else "license")]
        )

    def _query(self, name: str) -> SmartResult:
        if name == "today_sales":
            return SmartResult(
                reply="今日营业额要从主软件读数。点下面按钮打开「报表/概览」，我再教您看现金/微信/支付宝分项。也可做成自动读数（需主软件开放接口）。",
                kind="query",
                actions=[_act(self.product, "pos")],
                data={"query": "today_sales", "needs_host_api": True},
            )
        return SmartResult(reply="暂时只能帮您打开相关页面。", kind="fallback")


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--product", default="food")
    ap.add_argument("--q", default="帮我接微信支付")
    a = ap.parse_args()
    print(SmartAssistant(a.product).handle(a.q).to_json())


if __name__ == "__main__":
    main()
